import logo from './logo.svg';
import './App.css';
import Row from './component/Row';
import requests from './request';
import Banner from './component/Banner';
import Nav from './component/Nav';


function App() {
  return (
    <div className="App">
      <Nav/>
      <Banner/>



      <Row title="GENERAL NETFLIX" fetchUrl={requests.fetchNetflixOriginals} isLarger/>
      <Row title="Trending Now" fetchUrl={requests.fetchTrending}/> 
      <Row title="Top Rated" fetchUrl={requests.fetchTopRated}/> 
      <Row title=" Action Movies" fetchUrl={requests.fetchActionMovies}/>
      <Row title=" Horror Movies" fetchUrl={requests.fetchHorrorMovies}/>
      <Row title=" Comedies Movies" fetchUrl={requests.fetchComedyMovies}/>
      <Row title=" Documentary" fetchUrl={requests.fetchDocumentaries}/>
      <Row title=" Romances Movies" fetchUrl={requests.fetchRomanceMovies}/>
      
    </div>
  );
}

export default App;
