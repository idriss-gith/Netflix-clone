import React from 'react'
import logo from '../logo.svg';
import './nav.css'

function Nav(){


return (
    <div className="nav">
        
        <div >
            <img src={logo} />
        </div>
        <div>
            <a href="/">Login</a> |
            <a href="/">Register</a>
         
        </div>

    </div>
)

}


export default Nav;